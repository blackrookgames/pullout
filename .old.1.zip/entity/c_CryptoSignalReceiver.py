all = ['CryptoSignalReceiver']

from typing import\
    Callable as _Callable

type CryptoSignalReceiver = _Callable[[], None]