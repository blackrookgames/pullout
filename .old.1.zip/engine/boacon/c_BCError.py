all = ['BCError']

class BCError(Exception):
    """
    Raised when a boacon-related error occurs
    """
    pass