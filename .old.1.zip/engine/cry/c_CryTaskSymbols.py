all = ['CryTaskSymbols']

import ccxt as _ccxt

from ..helper.c_CLIError import\
    CLIError as _CLIError
from .c_CryTask import\
    CryTask as _CryTask

class CryTaskSymbols(_CryTask):
    """
    Represents a task to get available currencies
    """

    #region init

    def __init__(self):
        """
        Initializer for CryTaskSymbols
        """
        super().__init__()
        self.__symbols = []

    #endregion

    #region properties

    @property
    def symbols(self):
        """
        Available symbols
        """
        return self.__symbols

    #endregion

    #region CryTask
    
    def _main(self, exchange:_ccxt.coinbase):
        try:
            self.__symbols = exchange.get_symbols_for_market_type()
            return
        except Exception as _e:
            e = _CLIError(_e)
        raise e

    #endregion