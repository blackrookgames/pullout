__all__ = [ 'BadOpError' ]

class BadOpError:
    """
    Raised when attempting to run an invalid operation
    """
    pass