class BadOpError(Exception):
    """
    Raised when attempting to perform an invalid operation
    """
    pass